// Demo 17 Js file
$(document).ready(function() {
    'use strict';
});