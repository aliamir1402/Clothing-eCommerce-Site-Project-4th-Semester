<?php
 
$servername = 'localhost:3308';
 $username = 'root';
 $password = '';
 $dbname = 'store';
 $conn = mysqli_connect($servername, $username, $password, $dbname);

 $us = $_POST['register-email'];
 $pass = $_POST['register-password'];
 $name=$_POST['register-name0'];
 $phone=$_POST['register-phone'];
 

 $sql = "INSERT INTO `customer`(`c_name`, `c_username`, `c_password`,`phone`) VALUES ('$name','$us','$pass','$phone');";
 $result = mysqli_query($conn, $sql);

 

    if ($result) {
        echo '<div style="padding: 20px;
     background-color: green;
     color: white;">
     Registeration Successful!
     </div>';
    }
    else{
        echo '<div style="padding: 20px;
     background-color: red;
     color: white;">
     Registeration Not Working!           
     </div>';
    }
