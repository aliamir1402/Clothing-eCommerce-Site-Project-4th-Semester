<?php 
error_reporting(0);
session_start();
if (!isset($_SESSION['cart']))
{
    echo "cart not set\n";
    exit();
}
if(isset($_SESSION['cart']))
{
    $sum = 0;
    for ($i=0; $i < count($_SESSION['cart']) ; $i++) 
    { 
        $sum =$sum +( intval($_SESSION['cart'][$i]['quantity'])  * intval( $_SESSION['cart'][$i]['price']));
    }
}  
if(isset($_GET['ship_type']))
{
    $_SESSION['ship_fee'] = $_GET['ship_type'];
    $_SESSION['total'] = $sum + $_GET['ship_type'];
}

?>

<!DOCTYPE html>
<html lang="en">


<!-- molla/cart.html  22 Nov 2019 09:55:06 GMT -->
<head>
<style>
        .parent{
            background: none;
            color: black;
            font:inherit;
            background-color: transparent;
            border: none;
            font-weight: 500;
            font-size:120%;
        }
        .child{
            background-color: transparent;
            background: none;
            font-weight: 200;
            border: none;
            padding-top:10px;
            padding-bottom:10px;
        }
        .child:hover
        {
            color:#CC9966;
        }
    </style>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>CART</title>
    <meta name="keywords" content="HTML5 Template">
    <meta name="description" content="Molla - Bootstrap eCommerce Template">
    <meta name="author" content="p-themes">
    <!-- Favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="assets/images/icons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/images/icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/icons/favicon-16x16.png">
    <link rel="manifest" href="assets/images/icons/site.html">
    <link rel="mask-icon" href="assets/images/icons/safari-pinned-tab.svg" color="#666666">
    <link rel="shortcut icon" href="assets/images/icons/favicon.ico">
    <meta name="apple-mobile-web-app-title" content="Molla">
    <meta name="application-name" content="Molla">
    <meta name="msapplication-TileColor" content="#cc9966">
    <meta name="msapplication-config" content="assets/images/icons/browserconfig.xml">
    <meta name="theme-color" content="#ffffff">
    <!-- Plugins CSS File -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- Main CSS File -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
<div class="page-wrapper">
        <header class="header">
            <div class="header-top">
                <div class="container">
                    <div class="header-left">
                        <div class="header-dropdown">
                            <a href="#">Usd</a>
                            <div class="header-menu">
                                <ul>
                                    <li><a href="#">Eur</a></li>
                                    <li><a href="#">Usd</a></li>
                                </ul>
                            </div><!-- End .header-menu -->
                        </div><!-- End .header-dropdown -->

                        <div class="header-dropdown">
                            <a href="#">Eng</a>
                            <div class="header-menu">
                                <ul>
                                    <li><a href="#">English</a></li>
                                </ul>
                            </div><!-- End .header-menu -->
                        </div><!-- End .header-dropdown -->
                    </div><!-- End .header-left -->

                    <div class="header-right">
                        <ul class="top-menu">
                            <li>
                                <a href="#">Links</a>
                                <ul>
                                    <li><a href="tel:#"><i class="icon-phone"></i>Call: +92332-32119291</a></li>
                                    <li><a href="about.html">About Us</a></li>
                                    <li><a href="contact.html">Contact Us</a></li>
                                    <?php
                                      $servername = 'localhost:3308';
                                      $username = 'root';
                                      $password = '';
                                      $dbname = 'store';
                                      $conn = mysqli_connect($servername, $username, $password, $dbname);
                                     
                                      if (isset($_POST['singin-email']))
                                 {
                                      $us = $_POST['singin-email'];
                                      $pass = $_POST['singin-password'];
                                      setcookie("uname","",time()-3600);
                                      setcookie("uname",$us,time()+3600,"/");
                                      echo $_COOKIE["uname"];
                                      $sql = "SELECT c_username,c_password
                                      FROM customer
                                      WHERE c_username = '$us' AND c_password = '$pass';";
                                    $result = mysqli_query($conn, $sql);
                                    if (mysqli_num_rows($result)>0){
                                    $row = mysqli_fetch_assoc($result);
                                    $us = $row['c_username'];
                                    setcookie("root",$us,time() + (86400 * 30), "/");
                                    echo '<li><a href="order.php"><i class="icon-user" style="color:green;font-weight:bold;">' . $us . '</i></a>';
                                    }
                                    else {
                                        echo "&nbsp&nbsp&nbsp<span style='color:red;font-weight:bold;'>Login Failed!</span>";
                                    }
                                }
                                else{
                                    echo "<a href='login.php'>&nbsp&nbsp&nbsp<span style='color:black;'>Login</span></a>";
                                    setcookie("uname","",time()-3600);
                                      setcookie("uname","login",time()+3600,"/");
                                }
                                    ?></li>
                                </ul>
                            </li>
                        </ul><!-- End .top-menu -->
                    </div><!-- End .header-right -->
                </div><!-- End .container -->
            </div><!-- End .header-top -->

            <div class="header-middle sticky-header">
                <div class="container">
                    <div class="header-left">
                        <button class="mobile-menu-toggler">
                            <span class="sr-only">Toggle mobile menu</span>
                            <i class="icon-bars"></i>
                        </button>

                        <a href="Home.php" class="logo">
                            <img src="logo.jpg" alt="Brand Logo" width="105" height="25">
                        </a>

                        <nav class="main-nav">
                            <ul class="menu sf-arrows">
                                <li class="megamenu-container active">
                                    <a href="Home.php" class="sf-with-ul">Home</a>
                                </li>
                                <form action="Men-Category.php" method="GET">
                                    <li>
                                        <a href=""><button class="parent" name="Men" value="Men" type="submit" class="sf-with-ul">Men </button></a>

                                        <div class="megamenu megamenu-md">
                                            <div class="menu-title">Products</div>
                                            <!-- End .menu-title -->
                                            <ul>
                                                <li style="padding:5px;"><button class="child" name="Men" value="Tees" type="submit" class="sf-with-ul">Tees</button></li>
                                                <li style="padding:5px;"><button class="child" name="Men" value="Jackets" type="submit" class="sf-with-ul">Jackets</button></li>
                                                <li style="padding:5px;"><button class="child" name="Men" value="Trousers" type="submit" class="sf-with-ul">Trousers</button></li>
                                                <li style="padding:5px;"><button class="child" name="Men" value="Sweatshirts" type="submit" class="sf-with-ul">SweatShirts</button></li>
                                                <li style="padding:5px;"><button class="child" name="Men" value="Hoodies" type="submit" class="sf-with-ul">Hoodies</button></li>
                                </form>
                            </ul>
                    </div><!-- End .megamenu megamenu-md -->
                    </li>
                    <form action="Women-Category.php" method="GET">
                        <li>

                            <a href=""><button class="parent" name="Women" value="Women" type="submit" class="sf-with-ul">Women </button></a>

                            <div class="megamenu megamenu-sm">
                                <div style="padding:5px;" class="menu-title">Products</div>

                                <ul>
                                    <li style="padding:5px;"><button class="child" name="Women" value="Unstitched" type="submit" class="sf-with-ul">Unstiched</button></li>
                                    <li style="padding:5px;"><button class="child" name="Women" value="Stitched" type="submit" class="sf-with-ul">Stitched</button></li>
                                    <li style="padding:5px;"><button class="child" name="Women" value="Jeans" type="submit" class="sf-with-ul">Jeans</button></li>
                                    <li style="padding:5px;"><button class="child" name="Women" value="Hoodies" type="submit" class="sf-with-ul">Hoodies</button></li>
                    </form>
                    </ul>
                </div><!-- End .megamenu megamenu-sm -->

                </li>
                <form action="Kids-Category.php" method="GET">
                    <li>
                        <a href=""><button class="parent" name="Kids" value="Kids" type="submit" class="sf-with-ul">Kids </button></a>

                        <div class="megamenu megamenu-sm">
                            <div class="menu-title">Products</div>
                            <ul>
                                <li style="padding:5px;"><button class="child" name="Kids" value="Tees" type="submit" class="sf-with-ul">Tees</button></li>
                                <li style="padding:5px;"><button class="child" name="Kids" value="Eastern" type="submit" class="sf-with-ul">Eastern</button></li>
                                <li style="padding:5px;"><button class="child" name="Kids" value="Trousers" type="submit" class="sf-with-ul">Trousers</button></li>
                                <li style="padding:5px;"><button class="child" name="Kids" value="Swaetshirts" type="submit" class="sf-with-ul">Sweatshirts</button></li>
                </form>
                </ul>
            </div>
            </li>

            <li>
                <a href="blog.html" class="sf-with-ul">Accessories</a>

                <div class="megamenu megamenu-sm">
                    <div class="menu-title">Products</div>
                    <ul>
                        <li style="padding:5px;"><a href="#">Hand Bags</a></li>
                        <li style="padding:5px;"><a href="#">Key Chains</a></li>
                        <li style="padding:5px;"><a href="#">Laptop Covers </a></li>
                    </ul>
                </div>
            </li>

            </ul><!-- End .menu -->
            </nav><!-- End .main-nav -->
    </div><!-- End .header-left -->

    <div class="header-right">
        <div class="header-search">
            <a href="#" class="search-toggle" role="button" title="Search"><i class="icon-search"></i></a>
            <form action="Item-Search.php" method="post">
                <div class="header-search-wrapper">
                    <label for="q" class="sr-only">Search</label>
                    <input type="text" class="form-control" name="q" id="q" placeholder="Search in..." required>
                </div><!-- End .header-search-wrapper -->
            </form>
        </div><!-- End .header-search -->
                       
                        <div class="dropdown cart-dropdown">
                            <a href="#" class="dropdown-toggle" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-display="static">
                                <i class="icon-shopping-cart"></i>
                                <span class="cart-count"><?php 
                                
                                $len = count ($_SESSION['cart']);
                                if (!$len)
                                {
                                    $len = 0;
                                } 
                                echo $len;
                                ?></span>
                            </a>

                          
                            <div class="dropdown-menu dropdown-menu-right">
                                <div class="dropdown-cart-products">
                                    <?php 
                                    $len = count ($_SESSION['cart']);
                                    for ($i=0; $i < $len  ; $i++) { 
                                    
                                    
                              echo ("<form action='Product.php' method = 'GET'>  
                              <div class='product'>
                                        <div class='product-cart-details'>
                                            <h4 class='product-title'>
                                                <button style = 'background-color:transparent;border:none;' type = 'submit' name = 'cartlink' >".$_SESSION['cart'][$i]['title']."  </a>
                                            </h4>

                                            <span class='cart-product-info'>
                                                <span class='cart-product-qty'>  ".$_SESSION['cart'][$i]['quantity']." </span>
                                                x   ".$_SESSION['cart'][$i]['price']."
                                            </span>
                                        </div><!-- End .product-cart-details -->

                                        <figure class='product-image-container'>
                                            <input type = 'hidden' name = 'linkfromcart' value = ".$_SESSION['cart'][$i]['id'].">
                                            <button style = 'border: none; background-color:transparent;' type = 'submit' name = 'cartlink'  class='product-image'>
                                                <img src='".$_SESSION['cart'][$i]['src']."' alt='product'>
                                            </button>
                                        </figure>
                                        <a href='#' class='btn-remove' title='Remove Product'><i
                                                class='icon-close'></i></a>
                                    </div><!-- End .product -->
                                    </form>
                                    
                                    ");} ?>

                                    

                                <div class="dropdown-cart-total">
                                    <span>Total</span>

                                    <span class="cart-total-price">Rs. <?php echo $_SESSION['total'] ?></span>
                                </div><!-- End .dropdown-cart-total -->

                                <div class="dropdown-cart-action">
                                    <a href="cart.php" class="btn btn-primary">View Cart</a>
                                    <a href="checkout.html" class="btn btn-outline-primary-2"><span>Checkout</span><i
                                            class="icon-long-arrow-right"></i></a>
                                </div><!-- End .dropdown-cart-total -->
                            </div><!-- End .dropdown-menu -->
                        </div><!-- End .cart-dropdown -->
                    </div><!-- End .header-right -->
                </div><!-- End .container -->
            </div><!-- End .header-middle -->
        </header><!-- End .header -->

        <main class="main">
        	<div class="page-header text-center" style="background-image: url('assets/images/page-header-bg.jpg')">
        		<div class="container">
        			<h1 class="page-title">Shopping Cart<span>Shop</span></h1>
        		</div><!-- End .container -->
        	</div><!-- End .page-header -->
            <nav aria-label="breadcrumb" class="breadcrumb-nav">
                <div class="container">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="home.php">Home</a></li>
                        <li class="breadcrumb-item"><a href="#">Shop</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Shopping Cart</li>
                    </ol>
                </div><!-- End .container -->
            </nav><!-- End .breadcrumb-nav -->

            <div class="page-content">
            	<div class="cart">
	                <div class="container">
	                	<div class="row">
	                		<div class="col-lg-9">
	                			<table class="table table-cart table-mobile">
									<thead>
										<tr>
											<th>Product</th>
											<th>Price</th>
											<th>Quantity</th>
											<th>Total</th>
											<th></th>
										</tr>
									</thead>

									<tbody>
										<?php 
                                        for ( $i = 0 ;$i < count ($_SESSION['cart']) ; $i++)

                                       {
                                        echo ("
                                        <form method = 'get' action = 'Product.php'> <tr>
                                        <td class='product-col'>
                                            <div class='product'>
                                                <figure class='product-media'>
                                                    <button style = 'background-color:transparent; border:none;' name= 'linkfromcart' value = '".$_SESSION['cart'][$i]['id']."'>
                                                        <img src='".$_SESSION['cart'][$i]['src']."' alt='Product image'>
                                                    </button>
                                                </figure>

                                                <h3 class='product-title'>
                                                <button style = 'background-color:transparent; border:none;' name= 'linkfromcart' value = '".$_SESSION['cart'][$i]['id']."'>
                                                ".$_SESSION['cart'][$i]['title']."
                                            </button>
                                                </h3><!-- End .product-title -->
                                            </div><!-- End .product -->
                                        </td>
                                        <td class='price-col'>Rs.". $_SESSION['cart'][$i]['price']."</td>
                                        <td class='quantity-col'>
                                            <div class='cart-product-quantity'>
                                                <input type='number' class='form-control' value='".$_SESSION['cart'][$i]['quantity']."' min='1' max='10' step='1' data-decimals='0' required>
                                            </div><!-- End .cart-product-quantity -->
                                        </td>
                                        <td class='total-col'>Rs.".intval($_SESSION['cart'][$i]['price']) * intval($_SESSION['cart'][$i]['quantity'])."</td>
                                        <td class='remove-col'><button class='btn-remove'><i class='icon-close'></i></button></td>
                                        </form>
                                    </tr>");
                                       }
                                        ?>
										
									</tbody>
								</table><!-- End .table table-wishlist -->

	                			<div class="cart-bottom">
			            			<div class="cart-discount">
			            				<form action="#">
			            					<div class="input-group">
				        						<input type="text" class="form-control" required placeholder="coupon code">
				        						<div class="input-group-append">
													<button class="btn btn-outline-primary-2" type="submit"><i class="icon-long-arrow-right"></i></button>
												</div><!-- .End .input-group-append -->
			        						</div><!-- End .input-group -->
			            				</form>
			            			</div><!-- End .cart-discount -->

			            			<a href="#" class="btn btn-outline-dark-2"><span>UPDATE CART</span><i class="icon-refresh"></i></a>
		            			</div><!-- End .cart-bottom -->
	                		</div><!-- End .col-lg-9 -->
	                		<aside class="col-lg-3">
	                			<div class="summary summary-cart">
	                				<h3 class="summary-title">Cart Total</h3><!-- End .summary-title -->

	                				<table class="table table-summary">
	                					<tbody>
	                						<tr class="summary-subtotal">
	                							<td>Subtotal:</td>
	                							<td><?php echo "Rs. ".$sum;  ?></td>
	                						</tr><!-- End .summary-subtotal -->
	                						<tr class="summary-shipping">
	                							<td>Shipping:</td>
	                							<td>&nbsp;</td>
	                						</tr>
                                            <form action="" method = "GET">
                                            
	                						<tr class="summary-shipping-row">
	                							<td>
                                                <button value = '0' name ='ship_type' style = "background-color:transparent;border:none; " type = 'submit'>
													<div class="custom-control custom-radio">
														<input type="radio" id="free-shipping" name="free-shipping" class="custom-control-input" value = '0.00'>
														<label class="custom-control-label" for="free-shipping">Free </label>
													</div><!-- End .custom-control -->
	                							</td>
	                							<td>Rs. 0.00</td>
	                						</tr><!-- End .summary-shipping-row --></button>
                                           
	                						<tr class="summary-shipping-row">
	                							<td>
                                                <button value = '100' name ='ship_type' style = "background-color:transparent;border:none; " type = 'submit'>
	                								<div class="custom-control custom-radio">
														<input value = '100' type="radio" id="standard-shipping" name="shipping" class="custom-control-input">
														<label class="custom-control-label" for="standard-shipping">Standard:</label>
													</div><!-- End .custom-control -->
	                							</td>
	                							<td>Rs. 100</td>
	                						</tr><!-- End .summary-shipping-row --></button>
                                           
	                						<tr class="summary-shipping-row">
                                            
	                							<td>
                                                <button value = '200' name ='ship_type' style = "background-color:transparent;border:none; " type = 'submit'>
	                								<div class="custom-control custom-radio">
                                                            <input type="radio" id="express-shipping" name="shipping" class="custom-control-input">
														<label class="custom-control-label" for="express-shipping">Express:</label>
													</div><!-- End .custom-control -->
	                							</td>
	                							<td>Rs. 200</td>
                                                
	                						</tr><!-- End .summary-shipping-row --></button>

	                						

	                						<tr class="summary-total">
	                							<td>Total:</td>
	                							<td><?php 
                                                if (!isset($_SESSION['total'])) 
                                                {
                                                    echo $sum;
                                                }
                                                else
                                                {
                                                    echo $_SESSION['total'];
                                                }
                                                ?></td>
	                						</tr><!-- End .summary-total -->
	                					</tbody>
	                				</table><!-- End .table table-summary -->
                                    </form>
	                				<a  href = 'checkout.php' class="btn btn-outline-primary-2 btn-order btn-block">PROCEED TO CHECKOUT</a>
                                    
	                			</div><!-- End .summary -->

		            			<a href="category.html" class="btn btn-outline-dark-2 btn-block mb-3"><span>CONTINUE SHOPPING</span><i class="icon-refresh"></i></a>
	                		</aside><!-- End .col-lg-3 -->
	                	</div><!-- End .row -->
	                </div><!-- End .container -->
                </div><!-- End .cart -->
            </div><!-- End .page-content -->
        </main><!-- End .main -->

        <footer class="footer footer-dark">
            <div class="footer-middle">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-6 col-lg-3">
                            <div class="widget widget-about">
                                <img src="logo-removebg.png" class="footer-logo" alt="Footer Logo" width="105" height="25">


                                <div class="social-icons">
                                    <a href="https://www.facebook.com/" class="social-icon" title="Facebook" target="_blank"><i class="icon-facebook-f"></i></a>
                                    <a href="https://twitter.com/" class="social-icon" title="Twitter" target="_blank"><i class="icon-twitter"></i></a>
                                    <a href="https://www.instagram.com/?hl=en" class="social-icon" title="Instagram" target="_blank"><i class="icon-instagram"></i></a>
                                    <a href="https://www.youtube.com/" class="social-icon" title="Youtube" target="_blank"><i class="icon-youtube"></i></a>
                                </div><!-- End .soial-icons -->
                            </div><!-- End .widget about-widget -->
                        </div><!-- End .col-sm-6 col-lg-3 -->

                        <div class="col-sm-6 col-lg-3">
                            <div class="widget">
                                <h4 class="widget-title">Explore</h4><!-- End .widget-title -->

                                <ul class="widget-list">
                                    <li><a href="about.html">About Store</a></li>
                                    <li><a href="faq.html">FAQ</a></li>
                                    <li><a href="contact.html">Contact us</a></li>
                                </ul><!-- End .widget-list -->
                            </div><!-- End .widget -->
                        </div><!-- End .col-sm-6 col-lg-3 -->

                        <div class="col-sm-6 col-lg-3">
                            <div class="widget">
                                <h4 class="widget-title">My Account</h4><!-- End .widget-title -->

                                <ul class="widget-list">
                                    <li><a href="login.php">Sign In</a></li>
                                    <li><a href="login.php">Log In</a></li>
                                    <li><a href="cart.php">View Cart</a></li>
                                </ul><!-- End .widget-list -->
                            </div><!-- End .widget -->
                        </div><!-- End .col-sm-6 col-lg-3 -->

                        <div class="col-sm-6 col-lg-3">
                            <div class="widget">
                                <h4 class="widget-title">Customer Service</h4><!-- End .widget-title -->

                                <ul class="widget-list">
                                    <li><a href="#">Payment Methods</a></li>
                                    <li><a href="#">Terms and conditions</a></li>
                                    <li><a href="#">Privacy Policy</a></li>
                                </ul><!-- End .widget-list -->
                            </div><!-- End .widget -->
                        </div><!-- End .col-sm-6 col-lg-3 -->
                    </div><!-- End .row -->
                </div><!-- End .container -->
            </div><!-- End .footer-middle -->

            <div class="footer-bottom">
                <div class="container">
                    <p class="footer-copyright">Copyright © 2022 The Cloth Store. All Rights Reserved.</p>
                    <!-- End .footer-copyright -->
                    <figure class="footer-payments">
                        <img src="assets/images/payments.png" alt="Payment methods" width="272" height="20">
                    </figure><!-- End .footer-payments -->
                </div><!-- End .container -->
            </div><!-- End .footer-bottom -->
        </footer><!-- End .footer -->    </div><!-- End .page-wrapper -->
    <button id="scroll-top" title="Back to Top"><i class="icon-arrow-up"></i></button>

    <!-- Mobile Menu -->
    <div class="mobile-menu-overlay"></div><!-- End .mobil-menu-overlay -->

    <div class="mobile-menu-container">
        <div class="mobile-menu-wrapper">
            <span class="mobile-menu-close"><i class="icon-close"></i></span>

            <form action="#" method="get" class="mobile-search">
                <label for="mobile-search" class="sr-only">Search</label>
                <input type="search" class="form-control" name="mobile-search" id="mobile-search" placeholder="Search in..." required>
                <button class="btn btn-primary" type="submit"><i class="icon-search"></i></button>
            </form>
            
            <nav class="mobile-nav">
                <ul class="mobile-menu">
                    <li class="active">
                        <a href="index.php">Home</a>

                      
                    </li>
                    <li>
                        <a href="category.html">Shop</a>
                        <ul>
                            <li><a href="category-list.html">Shop List</a></li>
                            <li><a href="category-2cols.html">Shop Grid 2 Columns</a></li>
                            <li><a href="category.html">Shop Grid 3 Columns</a></li>
                            <li><a href="category-4cols.html">Shop Grid 4 Columns</a></li>
                            <li><a href="category-boxed.html"><span>Shop Boxed No Sidebar<span class="tip tip-hot">Hot</span></span></a></li>
                            <li><a href="category-fullwidth.html">Shop Fullwidth No Sidebar</a></li>
                            <li><a href="product-category-boxed.html">Product Category Boxed</a></li>
                            <li><a href="product-category-fullwidth.html"><span>Product Category Fullwidth<span class="tip tip-new">New</span></span></a></li>
                            <li><a href="cart.html">Cart</a></li>
                            <li><a href="checkout.html">Checkout</a></li>
                            <li><a href="wishlist.html">Wishlist</a></li>
                            <li><a href="#">Lookbook</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="product.html" class="sf-with-ul">Product</a>
                        <ul>
                            <li><a href="product.html">Default</a></li>
                            <li><a href="product-centered.html">Centered</a></li>
                            <li><a href="product-extended.html"><span>Extended Info<span class="tip tip-new">New</span></span></a></li>
                            <li><a href="product-gallery.html">Gallery</a></li>
                            <li><a href="product-sticky.html">Sticky Info</a></li>
                            <li><a href="product-sidebar.html">Boxed With Sidebar</a></li>
                            <li><a href="product-fullwidth.html">Full Width</a></li>
                            <li><a href="product-masonry.html">Masonry Sticky Info</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="#">Pages</a>
                        <ul>
                            <li>
                                <a href="about.html">About</a>

                                <ul>
                                    <li><a href="about.html">About 01</a></li>
                                    <li><a href="about-2.html">About 02</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="contact.html">Contact</a>

                                <ul>
                                    <li><a href="contact.html">Contact 01</a></li>
                                    <li><a href="contact-2.html">Contact 02</a></li>
                                </ul>
                            </li>
                            <li><a href="login.html">Login</a></li>
                            <li><a href="faq.html">FAQs</a></li>
                            <li><a href="404.html">Error 404</a></li>
                            <li><a href="coming-soon.html">Coming Soon</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="blog.html">Blog</a>

                        <ul>
                            <li><a href="blog.html">Classic</a></li>
                            <li><a href="blog-listing.html">Listing</a></li>
                            <li>
                                <a href="#">Grid</a>
                                <ul>
                                    <li><a href="blog-grid-2cols.html">Grid 2 columns</a></li>
                                    <li><a href="blog-grid-3cols.html">Grid 3 columns</a></li>
                                    <li><a href="blog-grid-4cols.html">Grid 4 columns</a></li>
                                    <li><a href="blog-grid-sidebar.html">Grid sidebar</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="#">Masonry</a>
                                <ul>
                                    <li><a href="blog-masonry-2cols.html">Masonry 2 columns</a></li>
                                    <li><a href="blog-masonry-3cols.html">Masonry 3 columns</a></li>
                                    <li><a href="blog-masonry-4cols.html">Masonry 4 columns</a></li>
                                    <li><a href="blog-masonry-sidebar.html">Masonry sidebar</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="#">Mask</a>
                                <ul>
                                    <li><a href="blog-mask-grid.html">Blog mask grid</a></li>
                                    <li><a href="blog-mask-masonry.html">Blog mask masonry</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="#">Single Post</a>
                                <ul>
                                    <li><a href="single.html">Default with sidebar</a></li>
                                    <li><a href="single-fullwidth.html">Fullwidth no sidebar</a></li>
                                    <li><a href="single-fullwidth-sidebar.html">Fullwidth with sidebar</a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="elements-list.html">Elements</a>
                        <ul>
                            <li><a href="elements-products.html">Products</a></li>
                            <li><a href="elements-typography.html">Typography</a></li>
                            <li><a href="elements-titles.html">Titles</a></li>
                            <li><a href="elements-banners.html">Banners</a></li>
                            <li><a href="elements-product-category.html">Product Category</a></li>
                            <li><a href="elements-video-banners.html">Video Banners</a></li>
                            <li><a href="elements-buttons.html">Buttons</a></li>
                            <li><a href="elements-accordions.html">Accordions</a></li>
                            <li><a href="elements-tabs.html">Tabs</a></li>
                            <li><a href="elements-testimonials.html">Testimonials</a></li>
                            <li><a href="elements-blog-posts.html">Blog Posts</a></li>
                            <li><a href="elements-portfolio.html">Portfolio</a></li>
                            <li><a href="elements-cta.html">Call to Action</a></li>
                            <li><a href="elements-icon-boxes.html">Icon Boxes</a></li>
                        </ul>
                    </li>
                </ul>
            </nav><!-- End .mobile-nav -->

            <div class="social-icons">
                <a href="#" class="social-icon" target="_blank" title="Facebook"><i class="icon-facebook-f"></i></a>
                <a href="#" class="social-icon" target="_blank" title="Twitter"><i class="icon-twitter"></i></a>
                <a href="#" class="social-icon" target="_blank" title="Instagram"><i class="icon-instagram"></i></a>
                <a href="#" class="social-icon" target="_blank" title="Youtube"><i class="icon-youtube"></i></a>
            </div><!-- End .social-icons -->
        </div><!-- End .mobile-menu-wrapper -->
    </div><!-- End .mobile-menu-container -->

    <!-- Sign in / Register Modal -->
    <div class="modal fade" id="signin-modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true"><i class="icon-close"></i></span>
                    </button>

                    <div class="form-box">
                        <div class="form-tab">
                            <ul class="nav nav-pills nav-fill" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="signin-tab" data-toggle="tab" href="#signin" role="tab" aria-controls="signin" aria-selected="true">Sign In</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="register-tab" data-toggle="tab" href="#register" role="tab" aria-controls="register" aria-selected="false">Register</a>
                                </li>
                            </ul>
                            <div class="tab-content" id="tab-content-5">
                                <div class="tab-pane fade show active" id="signin" role="tabpanel" aria-labelledby="signin-tab">
                                    <form action="#">
                                        <div class="form-group">
                                            <label for="singin-email">Username or email address *</label>
                                            <input type="text" class="form-control" id="singin-email" name="singin-email" required>
                                        </div><!-- End .form-group -->

                                        <div class="form-group">
                                            <label for="singin-password">Password *</label>
                                            <input type="password" class="form-control" id="singin-password" name="singin-password" required>
                                        </div><!-- End .form-group -->

                                        <div class="form-footer">
                                            <button type="submit" class="btn btn-outline-primary-2">
                                                <span>LOG IN</span>
                                                <i class="icon-long-arrow-right"></i>
                                            </button>

                                            <div class="custom-control custom-checkbox">
                                                <input type="checkbox" class="custom-control-input" id="signin-remember">
                                                <label class="custom-control-label" for="signin-remember">Remember Me</label>
                                            </div><!-- End .custom-checkbox -->

                                            <a href="#" class="forgot-link">Forgot Your Password?</a>
                                        </div><!-- End .form-footer -->
                                    </form>
                                    <div class="form-choice">
                                        <p class="text-center">or sign in with</p>
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <a href="#" class="btn btn-login btn-g">
                                                    <i class="icon-google"></i>
                                                    Login With Google
                                                </a>
                                            </div><!-- End .col-6 -->
                                            <div class="col-sm-6">
                                                <a href="#" class="btn btn-login btn-f">
                                                    <i class="icon-facebook-f"></i>
                                                    Login With Facebook
                                                </a>
                                            </div><!-- End .col-6 -->
                                        </div><!-- End .row -->
                                    </div><!-- End .form-choice -->
                                </div><!-- .End .tab-pane -->
                                <div class="tab-pane fade" id="register" role="tabpanel" aria-labelledby="register-tab">
                                    <form action="#">
                                        <div class="form-group">
                                            <label for="register-email">Your email address *</label>
                                            <input type="email" class="form-control" id="register-email" name="register-email" required>
                                        </div><!-- End .form-group -->

                                        <div class="form-group">
                                            <label for="register-password">Password *</label>
                                            <input type="password" class="form-control" id="register-password" name="register-password" required>
                                        </div><!-- End .form-group -->

                                        <div class="form-footer">
                                            <button type="submit" class="btn btn-outline-primary-2">
                                                <span>SIGN UP</span>
                                                <i class="icon-long-arrow-right"></i>
                                            </button>

                                            <div class="custom-control custom-checkbox">
                                                <input type="checkbox" class="custom-control-input" id="register-policy" required>
                                                <label class="custom-control-label" for="register-policy">I agree to the <a href="#">privacy policy</a> *</label>
                                            </div><!-- End .custom-checkbox -->
                                        </div><!-- End .form-footer -->
                                    </form>
                                    <div class="form-choice">
                                        <p class="text-center">or sign in with</p>
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <a href="#" class="btn btn-login btn-g">
                                                    <i class="icon-google"></i>
                                                    Login With Google
                                                </a>
                                            </div><!-- End .col-6 -->
                                            <div class="col-sm-6">
                                                <a href="#" class="btn btn-login  btn-f">
                                                    <i class="icon-facebook-f"></i>
                                                    Login With Facebook
                                                </a>
                                            </div><!-- End .col-6 -->
                                        </div><!-- End .row -->
                                    </div><!-- End .form-choice -->
                                </div><!-- .End .tab-pane -->
                            </div><!-- End .tab-content -->
                        </div><!-- End .form-tab -->
                    </div><!-- End .form-box -->
                </div><!-- End .modal-body -->
            </div><!-- End .modal-content -->
        </div><!-- End .modal-dialog -->
    </div><!-- End .modal -->

    <!-- Plugins JS File -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/jquery.hoverIntent.min.js"></script>
    <script src="assets/js/jquery.waypoints.min.js"></script>
    <script src="assets/js/superfish.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/bootstrap-input-spinner.js"></script>
    <!-- Main JS File -->
    <script src="assets/js/main.js"></script>
    
</body>


<!-- molla/cart.html  22 Nov 2019 09:55:06 GMT -->
</html>